<?php
/**
 * 
 * Q PHP FRAMEWORK, A Newcomer's Framework.
 * 
 * @author Air
 */
class HomeModel extends Model{
    //put your code here
    
}

?>
