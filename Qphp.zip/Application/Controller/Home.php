<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Index
 *
 * @author Administrator
 */
class Home {
    //put your code here
    public function index(){
        echo '<h1>Hello Q Framework!</h1>';
    }
}

?>
