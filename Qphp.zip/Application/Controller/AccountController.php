<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AccountController
 *
 * @author air
 */
class AccountController extends Controller{
    //put your code here
    
    public function index(){
        
    }
}

?>
