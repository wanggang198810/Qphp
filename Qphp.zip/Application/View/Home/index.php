<html>
    <head>
        <title><?php echo $title;?></title>
    </head>
<body>
    <?php
        Q::import('ko');
    ?>
    Hello,this is a App based on Q php framework !
    
    <a href="index.php?m=home&a=index">aa</a>
</body>
</html>
