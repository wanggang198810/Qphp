<?php
/**
 * 
 * Q PHP FRAMEWORK, A Newcomer's Framework.
 * 
 * @author Air
 */
class Template {
    //put your code here
    
    //模板引擎解析
    public function compile($template){
        return $template;
    }
    
}

?>
