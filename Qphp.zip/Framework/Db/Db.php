<?php
/**
 * 
 * Q PHP FRAMEWORK, A Newcomer's Framework.
 * 
 * @author Air
 */
class Db extends Db_Abstract implements Db_Interface{
    //put your code here
    
    
    
}

?>
